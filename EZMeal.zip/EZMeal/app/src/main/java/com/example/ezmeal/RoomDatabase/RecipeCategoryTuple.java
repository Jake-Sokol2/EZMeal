package com.example.ezmeal.RoomDatabase;

import androidx.room.ColumnInfo;
import androidx.room.Entity;

public class RecipeCategoryTuple
{
    @ColumnInfo (name = "pathToImage")
    public String pathToImage;
    @ColumnInfo (name = "title")
    public String title;
}