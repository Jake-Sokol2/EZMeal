package com.example.ezmeal.Repository;

// A repository is a class where we fetch data from API or DB.

import androidx.lifecycle.MutableLiveData;

public class AddListItemRepository {
    final MutableLiveData<String> mutableLiveData = new MutableLiveData<String>();

}
